# JavaProjects
This repository exist just for fun.
If You have a link on it please don't share it with another people without agreed author.
COPY AND OVERRIDE FILES WILL BE PUNISHED BY AUTHOR!!
author: Yushchenko Andrew
