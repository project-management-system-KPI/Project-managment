package main.java.ProjectComprehendWroteDigests;

public class Main {
    public static void main(String[] args) {
        MakerInputData inputData = new MakerInputData("D:\\Program\\JavaProjects\\Engineering Program Security\\template\\src\\main\\java\\ProjectComprehendWroteDigests\\NeuralNetworkFiles\\samples.png");
        inputData.readImage();
    }
}
