package main.java.com.lab111.labwork9;

public interface Prototype {
    Object copy();
}
