package main.java.com.lab111.labwork2;

public interface If1 extends If2 {

    public void method1();

    public void method2();

    public void method3();
}
