package main.java.com.lab111.labwork5;

public interface Observer {
    void update(int a, int r, int g, int b);

    void update();
}
