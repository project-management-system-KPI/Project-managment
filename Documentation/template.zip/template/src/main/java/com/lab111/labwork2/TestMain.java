package main.java.com.lab111.labwork2;

public class TestMain {
    public static void main(String[] args) {
        Cl1 cl1 = new Cl1();
        Cl2 cl2 = new Cl2();
        Cl3 cl3 = new Cl3();
        cl1.method3();
        cl2.method1();
        cl2.method2();
        cl3.method3();
        cl3.method2();
    }
}
