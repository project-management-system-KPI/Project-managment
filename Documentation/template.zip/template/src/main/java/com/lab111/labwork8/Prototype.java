package main.java.com.lab111.labwork8;

public interface Prototype {
    Object copy();
}
