package main.java.com.lab111.labwork3;

public interface Image {
    int checkPixelColor(int x, int y);

    void setSize(int width, int height);
}
