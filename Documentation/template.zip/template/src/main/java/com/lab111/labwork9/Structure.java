package main.java.com.lab111.labwork9;

import article.ActionEvent.ActionEvent;
import article.GUI.GUI;
import article.MainStructure;

public class Structure extends MainStructure {
    public Structure() {
        super();
    }

    public Structure(GUI gui, ActionEvent actionEvent) {
        super(gui, actionEvent);
    }

    @Override
    public void setGuisAndActionEvent(GUI gui, ActionEvent actionEvent) {
        super.setGuisAndActionEvent(gui, actionEvent);
    }
}
