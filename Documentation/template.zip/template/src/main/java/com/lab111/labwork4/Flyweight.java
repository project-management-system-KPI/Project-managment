package main.java.com.lab111.labwork4;

import java.awt.Rectangle;

public interface Flyweight {
    void draw(Rectangle rectangle);
    void setDraw(Draw draw);
}
