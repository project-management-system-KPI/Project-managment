package main.java.com.lab111.labwork9;

import article.ActionEvent.ActionEvent;

public interface Builder {
    void buildShape(int[] data);
    void setAction(Action action);
}
