package main.java.com.lab111.labwork2;

public class Cl3 extends Cl1 implements If3 {

    @Override
    public void method1() {
        System.out.println("Method 1 - Class 3");
    }

    @Override
    public void method2() {
        System.out.println("Method 2 - Class 3");
    }

    @Override
    public void method3() {
        System.out.println("Method 3 - Class 3");
    }
}
