package main.java.com.lab111.labwork2;

public class Cl1 implements If1 {

    @Override
    public void method1() {
        System.out.println("Method 1 - Class 1");
    }

    @Override
    public void method2() {
        System.out.println("Method 2 - Class 1");
    }

    @Override
    public void method3() {
        System.out.println("Method 3 - Class 1");
    }
}
