package main.java.com.lab111.labwork2;

import javax.swing.*;

public class test {
    private JTextArea textArea1;
    private JTable table1;
    private JSpinner spinner1;
    private JSlider slider1;
}
