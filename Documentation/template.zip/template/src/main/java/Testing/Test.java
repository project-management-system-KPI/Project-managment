package main.java.Testing;

import javax.swing.*;

public class Test {
    private JList list1;
    private JPanel panel1;
    private JProgressBar progressBar1;
    private JTree tree1;
    private JComboBox comboBox1;
}
