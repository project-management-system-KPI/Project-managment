package main.java.LeetCode.Task2;

public class ListNode {
    int val;
    ListNode next;
    ListNode(int x) { val = x; }
}
